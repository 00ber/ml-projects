tar -czvf wassa2023-shared-task.tar.gz ./*
